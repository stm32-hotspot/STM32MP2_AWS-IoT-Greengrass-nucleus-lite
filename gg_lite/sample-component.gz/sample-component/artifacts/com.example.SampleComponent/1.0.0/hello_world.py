#import sys

#message = "Hello, World!"

# Print the message to stdout, which Greengrass saves in a log file.
#print(message)

def main():
    print("HELLO WORLD")
#    fetch_s3_bucket_list()


if __name__ == "__main__":
    main()
